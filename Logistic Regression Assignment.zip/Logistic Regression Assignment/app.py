import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os

# Load the trained model
model_path = 'logistic_regression_model.pkl'
if not os.path.exists(model_path):
    st.error(f"Model file '{model_path}' not found. Please run train_local.py first.")
    st.stop()

try:
    model = joblib.load(model_path)
except Exception as e:
    st.error(f"Error loading the model: {e}")
    st.stop()

st.title('Titanic Survival Prediction')
st.write("This app predicts the survival probability of a passenger on the Titanic")

# User input
pclass = st.selectbox('Pclass', [1, 2, 3])
sex = st.selectbox('Sex', ['female', 'male'])
age = st.slider('Age', 0, 80, 30)
sibsp = st.slider('SibSp', 0, 8, 0)
parch = st.slider('Parch', 0, 6, 0)
fare = st.number_input('Fare', value=50.0)
embarked = st.selectbox('Embarked', ['C', 'Q', 'S'])

# Map categorical inputs
sex_map = {'female': 0, 'male': 1}
embarked_map = {'C': 0, 'Q': 1, 'S': 2}

# Prepare input dataframe matching training features
input_data = pd.DataFrame({
    'PassengerId': [0],  # dummy
    'Pclass': [pclass],
    'Name': [0],         # dummy
    'Sex': [sex_map[sex]],
    'Age': [age],
    'SibSp': [sibsp],
    'Parch': [parch],
    'Ticket': [0],       # dummy
    'Fare': [fare],
    'Cabin': [0],        # dummy
    'Embarked': [embarked_map[embarked]]
})

# Predict when user clicks button
if st.button('Predict Survival'):
    try:
        # Ensure we call predict on the trained model pipeline
        prediction = model.predict(input_data)
        prediction_proba = model.predict_proba(input_data)[:, 1]

        st.subheader('Prediction')
        st.write('Survived' if prediction[0] == 1 else 'Did not survive')

        st.subheader('Survival Probability')
        st.write(f"{prediction_proba[0]:.2f}")
    except AttributeError:
        st.error("The loaded model is not a trained pipeline. Please retrain using train_local.py")
