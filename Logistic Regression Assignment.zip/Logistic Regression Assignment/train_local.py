import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
import joblib

# Load the dataset
df_train = pd.read_csv('Titanic_train.csv')
df_test = pd.read_csv('Titanic_test.csv')

# Impute missing values
df_train['Age'].fillna(df_train['Age'].mean(), inplace=True)
df_train['Embarked'].fillna(df_train['Embarked'].mode()[0], inplace=True)
df_train['Cabin'].fillna(df_train['Cabin'].mode()[0], inplace=True)

df_test['Age'].fillna(df_test['Age'].mean(), inplace=True)
df_test['Fare'].fillna(df_test['Fare'].mean(), inplace=True)
df_test['Cabin'].fillna(df_test['Cabin'].mode()[0], inplace=True)

# Remove outliers using IQR
numerical_cols_train = df_train.select_dtypes(include=['int64','float64']).columns
for col in numerical_cols_train:
  Q1 = df_train[col].quantile(0.25)
  Q3 = df_train[col].quantile(0.75)
  IQR = Q3 - Q1
  df_train = df_train[~((df_train[col] < (Q1 - 1.5 * IQR)) | (df_train[col] > (Q3 + 1.5 * IQR)))]

numerical_cols_test = df_test.select_dtypes(include=['int64','float64']).columns
for col in numerical_cols_test:
  Q1 = df_test[col].quantile(0.25)
  Q3 = df_test[col].quantile(0.75)
  IQR = Q3 - Q1
  df_test = df_test[~((df_test[col] < (Q1 - 1.5 * IQR)) | (df_test[col] > (Q3 + 1.5 * IQR)))]


# Label Encoding for categorical features
le = LabelEncoder()
for col in ['Name', 'Sex', 'Ticket', 'Embarked', 'Cabin']:
    if col in df_train.columns:
        df_train[col] = le.fit_transform(df_train[col])
    if col in df_test.columns:
        # Use the classes from the training data encoder to transform the test data
        # This is important to handle unseen categories in test data gracefully
        # although for this specific dataset, the categories are likely consistent
        # between train and test after the outlier removal.
        # A more robust approach for unseen categories would be to use handle_unknown='ignore' in OneHotEncoder,
        # but since we are using LabelEncoder here, we will fit it on combined data first or handle errors.
        # For simplicity and based on the original notebook's approach with separate LabelEncoders,
        # we will fit a new encoder on the test data. This might be a point for improvement
        # in a real-world scenario.
        le_test = LabelEncoder()
        df_test[col] = le_test.fit_transform(df_test[col])


# Define features and target variable
X = df_train.drop('Survived', axis=1)
Y = df_train['Survived']

# Standardize and apply logistic regression
model = make_pipeline(StandardScaler(), LogisticRegression())
model.fit(X, Y)

# Save the trained model to a file
joblib.dump(model, "logistic_regression_model.pkl")

print("Model training complete and saved to logistic_regression_model.pkl")
